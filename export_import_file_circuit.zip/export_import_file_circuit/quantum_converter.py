import sys
import os
from qiskit_aer import Aer, StatevectorSimulator
from qiskit.quantum_info import Statevector, state_fidelity, DensityMatrix
from qiskit.quantum_info import Operator
from qiskit import transpile
from qiskit.providers.fake_provider import GenericBackendV2
from circuit_utils import (
    create_circuit_from_file,
    create_file_from_circuit,
    create_circuit_from_simple_file,
    load_adjacency_matrix_from_file,
    matrix_to_coupling_map,
    count_cnots
)
import numpy as np
from cnot_synth import run_java_cnotsynth

def main():
    if len(sys.argv) != 6:
        print("Uso: <matrice_adiacenza.txt> <cnotsynth.jar> <cartella_input> <cartella_output> <cartella_results>")
        sys.exit(1)

    filepath_adj = sys.argv[1]
    filepath_jar = sys.argv[2]
    folder_input = sys.argv[3]
    folder_output = sys.argv[4]
    folder_results = sys.argv[5]

    # Creazione cartelle output e results se non esistono
    os.makedirs(folder_output, exist_ok=True)
    os.makedirs(folder_results, exist_ok=True)

    if not os.path.isfile(filepath_adj):
        print(f"Errore: file matrice adiacenza non trovato: {filepath_adj}")
        sys.exit(1)

    if not os.path.isfile(filepath_jar):
        print(f"Errore: file JAR non trovato: {filepath_jar}")
        sys.exit(1)

    if not os.path.isdir(folder_input):
        print(f"Errore: cartella di input non trovata: {folder_input}")
        sys.exit(1)

    # Carica la matrice di adiacenza e crea la coupling map
    adj_matrix = load_adjacency_matrix_from_file(filepath_adj)
    coupling_map = matrix_to_coupling_map(adj_matrix)

    results = []

    # Itera su tutti i file nella cartella input
    for filename in os.listdir(folder_input):
        filepath_input = os.path.join(folder_input, filename)
        if not filename.endswith(".txt"):
            continue  # Ignora file non di testo

        output_filename = f"{filename.replace('.txt', '')}_Output.txt"
        filepath_output = os.path.join(folder_output, output_filename)

        # Carica il circuito originale
        qc_original = create_circuit_from_simple_file(filepath_input)

        # Conta le CNOT nel circuito originale
        cnot_original = count_cnots(qc_original)

        # Transpile con Qiskit
        layout = list(range(qc_original.num_qubits))
        
        qc_qiskit = transpile(
            qc_original,
            coupling_map=coupling_map,
            backend=GenericBackendV2(num_qubits=9, noise_info=False),
           # basis_gates=['cx', 'h', 's', 'sdg', 'tdg', 't', 'x', 'y', 'z'],
            initial_layout=layout,
            layout_method="trivial",
            seed_transpiler=1,
            optimization_level=0
        )

        # Salva il circuito in formato compatibile per la sintesi
        create_file_from_circuit(qc_original, filepath_input, ['CNOT', 'H', 'S', 'S+', 'T', 'T+', 'X', 'Y', 'Z'])

        # Esegui la sintesi con il JAR
        run_java_cnotsynth(filepath_adj, filepath_input, filepath_output, filepath_jar)

        # Crea il circuito sintetizzato
        qc_java = create_circuit_from_file(filepath_output)

        # Confronto: fidelity tra circuiti
        density_matrix_qc_original = DensityMatrix(qc_original)
        density_matrix_qc_qiskit = DensityMatrix(qc_qiskit)
        density_matrix_qc_java = DensityMatrix(qc_java)

       
        

        """simulator = StatevectorSimulator()
        state_original = simulator.run(qc_original).result().get_statevector()
        state_qiskit = simulator.run(qc_qiskit).result().get_statevector()
        state_java = simulator.run(qc_java).result().get_statevector()"""

        fidelity_qiskit = state_fidelity(density_matrix_qc_original, density_matrix_qc_qiskit)
        fidelity_java = state_fidelity(density_matrix_qc_original, density_matrix_qc_java)

        print(f"file: {filepath_input} fidelity_qiskit: {fidelity_qiskit}")
        print(f"file: {filepath_input} fidelity_java: {fidelity_java}")



        """U_orig = Operator(qc_original).data
        U_trans = Operator(qc_qiskit).data
        U_java = Operator(qc_java).data


        fidelity_qiskit = np.abs(np.trace(np.dot(np.conj(U_orig.T), U_trans))) / (2 ** qc_original.num_qubits)
        fidelity_java = np.abs(np.trace(np.dot(np.conj(U_orig.T), U_java))) / (2 ** qc_original.num_qubits)"""



        # Conta le CNOT
        cnot_qiskit = count_cnots(qc_qiskit)
        cnot_java = count_cnots(qc_java)

        # Salva i risultati
        results.append((filename, os.path.basename(filepath_adj), cnot_original, cnot_qiskit, cnot_java, fidelity_qiskit, fidelity_java))

    # Scrivi i risultati nella cartella results
    results_file = os.path.join(folder_results, "my_results_statefidelity.txt")
    with open(results_file, "w") as f:
        f.write(f"{'File Input':<25} {'Matrice Adiacenza':<25} {'CNOT Originale':<15} {'CNOT Qiskit':<15} {'CNOT Java':<15} {'Fidelity Qiskit':<20} {'Fidelity Java':<20}\n")
        f.write("=" * 140 + "\n")
        for row in results:
            f.write(f"{row[0]:<25} {row[1]:<25} {row[2]:<15} {row[3]:<15} {row[4]:<15} {row[5]:<20.6f} {row[6]:<20.6f}\n")

    print(f"Processo completato! Risultati salvati in {results_file}")

if __name__ == "__main__":
    main()
